package com.cattlego.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cattlego.model.cattle;
@Repository("cattleDataRepository")
public interface cattle_repo extends JpaRepository<cattle, Integer>, JpaSpecificationExecutor<cattle> {
	
	// @Query("select j from cattle j where j.year = year")
	List<cattle> findByYear(String year);
	
	// @Query("select j from cattle j where j.state = state")

	List<cattle> findByState(String state);
	@Query("select j from cattle j where j.state = state and j.year = year")
	List<cattle> findByStateYear(String state, String year);

}
