package com.cattlego.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "survey")
public class survey {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "rate")
	private String rate;
	@Column(name = "bigproblem")
	private String bigProblem;
	@Column(name = "likemost")
	private String likeMost;
	@Column(name = "likeleast")
	private String likeLeast;
	@Column(name = "helpful")
	private String helpful;
	@Column(name = "industry")
	private String industry;
	
	public survey() {
	}

	public survey(int id, String rate, String bigProblem, String likeMost, String likeLeast, String helpful, String industry) {
		super();
		this.id = id;
		this.rate = rate;
		this.bigProblem = bigProblem;
		this.likeMost = likeMost;
		this.likeLeast = likeLeast;
		this.helpful = helpful;
		this.industry = industry;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

	public String getBigProblem() {
		return bigProblem;
	}

	public void setBigProblem(String bigProblem) {
		this.bigProblem = bigProblem;
	}

	public String getLikeMost() {
		return likeMost;
	}

	public void setLikeMost(String likeMost) {
		this.likeMost = likeMost;
	}

	public String getLikeLeast() {
		return likeLeast;
	}

	public void setLikeLeast(String likeLeast) {
		this.likeLeast = likeLeast;
	}

	public String getHelpful() {
		return helpful;
	}

	public void setHelpful(String helpful) {
		this.helpful = helpful;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}
	
	
	
	

}
