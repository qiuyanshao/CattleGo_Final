package com.cattlego.model;

import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "cattle")
public class cattle {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private int id;
	@Column(name = "year")
	private String year;
	@Column(name = "state")
	private String state;
	@Column(name = "cattle")
	private double cattle;
	@Column(name = "corn")
	private int corn;
	@Column(name = "soybeans")
	private double soybeans;	
	@Column(name = "tmax")
	private double tmax;
	@Column(name = "tmin")
	private double tmin;
	@Column(name = "tavg")
	private double tavg;
	@Column(name = "emxt")
	private double emxt;
	@Column(name = "emnt")
	private double emnt;
	@Column(name = "dx90")
	private double dx90;
	@Column(name = "dt32")
	private double dt32;
	@Column(name = "prcp")
	private double prcp;
	@Column(name = "snow")
	private double snow;
	@Column(name = "awnd")
	private double awnd;
	
	

	public cattle() {
		
	}



	public cattle(String year, String state, double cattle, int corn, double soybeans,
			double tmax, double tmin, double tavg, double emxt, double emnt, double dx90, double dt32, double prcp,
			double snow, double awnd) {
		super();
		this.year = year;
		this.state = state;
		this.cattle = cattle;
		this.corn = corn;
		this.soybeans = soybeans;
		this.tmax = tmax;
		this.tmin = tmin;
		this.tavg = tavg;
		this.emxt = emxt;
		this.emnt = emnt;
		this.dx90 = dx90;
		this.dt32 = dt32;
		this.prcp = prcp;
		this.snow = snow;
		this.awnd = awnd;
	}



	public int getId() {
		return id;
	}



	public void setId(int id) {
		this.id = id;
	}



	public String getYear() {
		return year;
	}



	public void setYear(String year) {
		this.year = year;
	}



	public String getState() {
		return state;
	}



	public void setState(String state) {
		this.state = state;
	}



	public double getCattle() {
		return cattle;
	}



	public void setCattle(double cattle) {
		this.cattle = cattle;
	}



	public int getCorn() {
		return corn;
	}



	public void setCorn(int corn) {
		this.corn = corn;
	}



	public double getSoybeans() {
		return soybeans;
	}



	public void setSoybeans(double soybeans) {
		this.soybeans = soybeans;
	}



	public double getTmax() {
		return tmax;
	}



	public void setTmax(double tmax) {
		this.tmax = tmax;
	}



	public double getTmin() {
		return tmin;
	}



	public void setTmin(double tmin) {
		this.tmin = tmin;
	}



	public double getTavg() {
		return tavg;
	}



	public void setTavg(double tavg) {
		this.tavg = tavg;
	}



	public double getEmxt() {
		return emxt;
	}



	public void setEmxt(double emxt) {
		this.emxt = emxt;
	}



	public double getEmnt() {
		return emnt;
	}



	public void setEmnt(double emnt) {
		this.emnt = emnt;
	}



	public double getDx90() {
		return dx90;
	}



	public void setDx90(double dx90) {
		this.dx90 = dx90;
	}



	public double getDt32() {
		return dt32;
	}



	public void setDt32(double dt32) {
		this.dt32 = dt32;
	}



	public double getPrcp() {
		return prcp;
	}



	public void setPrcp(double prcp) {
		this.prcp = prcp;
	}



	public double getSnow() {
		return snow;
	}



	public void setSnow(double snow) {
		this.snow = snow;
	}



	public double getAwnd() {
		return awnd;
	}



	public void setAwnd(double awnd) {
		this.awnd = awnd;
	}
	
	



}
