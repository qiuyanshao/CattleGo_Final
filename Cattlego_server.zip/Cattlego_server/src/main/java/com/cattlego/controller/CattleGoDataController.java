package com.cattlego.controller;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.cattlego.model.cattle;
import com.cattlego.model.survey;
import com.cattlego.repository.cattle_repo;
import com.cattlego.repository.survey_repo;
import org.springframework.http.HttpStatus;
 @CrossOrigin(origins = "http://localhost:4200", maxAge = 3600)
@RestController
@RequestMapping(path = {"/cattlego"})
public class CattleGoDataController {
	private static Logger LOGGER = LoggerFactory.getLogger(CattleGoDataController.class);
	@Autowired
	private cattle_repo cattleDataRepository;
	@Autowired
	private  survey_repo surveyRepository;
	
	

	@GetMapping(path = { "/datasources" })
	public List<cattle> getAllDataSources() {
		LOGGER.info("get All Data Sources======================");
		return cattleDataRepository.findAll();

	}
	
	@GetMapping(path = { "/datasources/year/{year}" })
	public List<cattle> getCattleByYear(@PathVariable("year") String year) {
		List<cattle> cattles = cattleDataRepository.findByYear(year);
		LOGGER.info("get cattles by year======================");
		return cattles;
	}
	
	@GetMapping(path = { "/datasources/state/{state}" })
	public List<cattle> getCattleByState(@PathVariable("state") String state) {
		List<cattle> cattles = cattleDataRepository.findByState(state);
		LOGGER.info("get cattles by state======================");
		return cattles;
	}
	
	
	// survey
	
	@GetMapping(path = { "/surveys" })
	public List<survey> getAllsurveys() {

		return surveyRepository.findAll();

	}

	@PutMapping(path = { "/survey" })
	// @RequestMapping(value = { "/allsurveys" }, method = RequestMethod.GET)
	public survey updatesurvey(@RequestBody survey ds) {
		return surveyRepository.save(ds);
	}

	@GetMapping(path = { "/survey/{surveyid}" })
	// @RequestMapping(value = { "/allsurveys" }, method = RequestMethod.GET)
	public survey getsurvey(@PathVariable("surveyid") int surveyid) {
		return surveyRepository.findOne(surveyid);
	}

	
	@DeleteMapping(path = { "/survey/{surveyid}" })
	// @RequestMapping(value = { "/allsurveys" }, method = RequestMethod.GET)
	public boolean deletesurvey(@PathVariable("surveyid") int surveyid) {
		surveyRepository.delete(surveyid);

		return true;
	}

	// (2) used in angular  ===> create a new survey
	@PostMapping(path = { "/survey" })
	@ResponseStatus(HttpStatus.OK)
	public void newsurveyForm(@RequestBody survey ds) {

		surveyRepository.save(ds);
		LOGGER.info("survey Form submitted successfully=======================");

	
	}
	
	
	
	
	



}